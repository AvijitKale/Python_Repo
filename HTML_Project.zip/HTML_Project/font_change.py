##### This code is for font change and look up ###############
##### Autor: Avijit Kale ############################


import codecs
from bs4 import BeautifulSoup
import requests, re
import string

flagPre = False
flagExp = False
flagTable = False


f1 = codecs.open("append.html", 'r', 'utf-8')

f2 = open('new_append.html', 'w')


for line in f1.readlines():

	if "Preconditions:" in line:

		flagPre = True

	if flagPre and ("</div><p>" in line or "<td><p>" in line or "<p>" in line):

		line = line.replace('<p>','<font size="2" face="Verdana" ><p>' )

	if flagPre and "</p></td>" in line:

		line = line.replace('</p>','</p></font>')


	if "Expected Results:" in line:

		flagExp = True
		flagPre = False
	if ("</div><p>" in line or "<td><p>" in line or "<p>" in line) and flagExp:

		line = line.replace('<p>','<font size="2" face="Verdana" ><p>')
                       
	if ("</p></td>" in line or "<p>" in line) and flagExp:

		line = line.replace('</p>','</p></font>')

	if "</table>" in line:
		flagTable = True

	if "</font></div>" in line and (flagTable == False):
		flagTable = False
		line = line.replace('</font></div>', '</table></div></font></div>')


	if "</font></div>" in line:
		flagExp = False
		flagPre = False
		flagTable = False

	
	f2.write(line)


f1.close()
f2.close()
	
	
