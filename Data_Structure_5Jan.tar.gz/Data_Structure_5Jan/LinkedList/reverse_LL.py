class Node:
    def __init__(self,data):
        self.data = data
	self.next = None

class LinkedList:
    def __init__(self):
	self.head = None

    def push(self,new_data):
	new_node = Node(new_data)
	new_node.next = self.head
	self.head = new_node

    def reverseList(self):
	current = self.head
	prev = None
	while(current):
	    next = current.next
	    current.next = prev
	    prev = current
	    current = next

	self.head = prev

    def lengthList(self):
	current = self.head
	count = 0
	while(current):
	    current = current.next
	    count = count +1
	return count	

    def printList(self):
	temp = self.head
	while(temp):
	    print "%d" %temp.data
	    temp = temp.next


llist = LinkedList()
llist.push(2)
llist.push(3)
llist.push(6)
llist.push(9)
llist.push(5)
count = llist.lengthList()
print "length of list is:%d" % count

print "Original List:\n"
llist.printList()

llist.reverseList()

print "After reversing List:\n"
llist.printList()

