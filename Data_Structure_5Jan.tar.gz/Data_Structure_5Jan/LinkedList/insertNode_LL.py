class Node:
    def __init__(self,data):
	self.data = data
	self.next = None

class LinkedList:
    def __init__(self):
	self.head = None

    def push(self, new_data):
	new_node = Node(new_data)
	new_node.next = self.head
	self.head = new_node

    def insertAfter(self,prev,new_data):
	new_node = Node(new_data)
	new_node.next = prev.next
	prev.next = new_node

    def printList(self):
	temp = self.head
	while(temp):
	    print "%d" %temp.data
	    temp = temp.next

    def insertAfterPosition(self,position,new_data):
	new_node = Node(new_data)
	if position == 0:
	    new_node.next = self.head
	    self.head = new_node
	else:
	    temp = self.head
	    for i in range(position-1):
	        if temp is not None:
	            temp = temp.next
	
	    new_node.next = temp.next
	    temp.next = new_node

	
	
	    

llist = LinkedList()

llist.push(7)
llist.push(2)
llist.push(3)

llist.printList()

llist.insertAfter(llist.head.next.next,10)

print "List after inserting data\n"

llist.printList()

print "List after inserting after 2 Position:\n"

llist.insertAfterPosition(2,17)

llist.printList()


print "List after inserting after 0 Position:\n"

llist.insertAfterPosition(0,15)

llist.printList()
