# Python program to find the maximum depth of tree
 
# A binary tree node
class Node:
 
    # Constructor to create a new node
    def __init__(self, data):
        self.data = data
        self.left = None
        self.right = None
 
# Compute the "maxDepth" of a tree -- the number of nodes 
# along the longest path from the root node down to the 
# farthest leaf node
def maxData(node, max):
	if node.data > max:
		max = node.data

	if node.left != None:
		max = maxData(node.left, max)
	if node.right != None:
		max = maxData(node.right, max)

	return max
 
# Driver program to test above function
root = Node(8)
root.left = Node(33)
root.right = Node(23)
root.left.left = Node(21)
root.left.right = Node(19)
root.left.right.right = Node(7)
root.left.right.right.left = Node(16)
print "Max of tree is %d",(maxData(root,root.data))
 
