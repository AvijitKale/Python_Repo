

# A binary tree node
class Node:

    # Constructor to create a new node
    def __init__(self, data):
        self.data = data
        self.left = None
        self.right = None


def postorderTraversal(root):
        # Handle with the special cast (empty input)
        if root == None:        return []
 
        # Every node will be accessed twice in the stacks.
        #
        # As post order traversal required:
        # The first time, we will pop and check its son(s).
        # The second time, we will check its value.
        #
        # So we are using two stacks here. One for the nodes to be accessed
        # for the first time. The other is used for the nodes, waiting for
        # the second access.
        stackPrepare = [root]
        stackReady = []
        result = []
 
        while len(stackPrepare) != 0 :
            current = stackPrepare.pop()
 
            # Current node is finally read after reading its son(s). So
            # it is pushed firstly.
            stackReady.append(current)
 
            # The sons are going to travel tow stacks, which are FILO.
            # We want to read left son first, if it exists.
            # So we push the left son first. Please notice that, in the
            # first stack, it would be left -> right
            # When in the second stack, it would be root -> right -> left
            # And final when reading the value into result, the order is:
            # left -> right -> root, as post order traversal.
            if current.left  != None:   stackPrepare.append(current.left)
            if current.right != None:   stackPrepare.append(current.right)
 
        while len(stackReady) != 0:
            result.append(stackReady.pop().data)
 
        return result


# Driver program to test above function
root = Node(1)
root.left      = Node(2)
root.right     = Node(3)
root.left.left  = Node(4)
root.left.right  = Node(5)

result = []
result = postorderTraversal(root)

print result

