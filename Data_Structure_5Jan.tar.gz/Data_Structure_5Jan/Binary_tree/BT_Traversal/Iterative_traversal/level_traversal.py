"""
printLevelorder(tree)
1) Create an empty queue q
2) temp_node = root /*start from root*/
3) Loop while temp_node is not NULL
    a) print temp_node->data.
    b) Enqueue temp_node’s children (first left then right children) to q
    c) Dequeue a node from q and assign it’s value to temp_node

"""

class Node:
	def __init__(self, data):
		self.data =  data
		self.left = None
		self.right = None

def LevelTraversal(root):

	queue = []

	result = []

	if root is None:
		return

	queue.append(root)

	while len(queue) > 0:

		node = queue.pop(0)

		result.append(node.data)

		if node.left is not None:
			queue.append(node.left)
		if node.right is not None:
			queue.append(node.right)

	return result


root = Node(1)

root.left = Node(2)

root.right = Node(3)

root.left.left = Node(4)

root.left.right = Node(5)

result = []

result = LevelTraversal(root)

print result
