from pythonds.basic.stack import Stack


def dec_to_bin(num):
	s = Stack()
	
	while num > 0:
		rem = num % 2
		s.push(rem)
		num = num // 2

	string = ""
	while not s.isEmpty():
		string = string + str(s.pop())

	print "Inside fun:", string

	return string


if __name__ == '__main__':
	print (dec_to_bin(21))
