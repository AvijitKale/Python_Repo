from pythonds.basic.stack import Stack

def par_check(string):

	index = 0
	print "Length of string: ", len(string)
	s = Stack()
	balanced = True
	while index < len(string) and (balanced == True):
		symbol = string[index]
		print "symbol: ", symbol

		if symbol in "({[":
			s.push(symbol)

		elif symbol in ")}]":
			if s.isEmpty():
				balanced = False
			else:
				top = s.pop()
				if not matches(top,symbol):
					balanced = False
		elif symbol == " ":
			pass
		else:	
			pass
		index = index +1



	if balanced  and s.isEmpty():
		return True
	else:
		return False

def matches(open,close):
	opens = "({["
	closes = ")}]"
	return opens.index(open) == closes.index(close)

if __name__ == '__main__':
	flag = None
	string = "(as{dsd[as(sa)a]sa}asasa)"
	flag = par_check(string)
#	print flag
	if flag:
		print "Balanced"
	else:
		print "Imbalanced"
