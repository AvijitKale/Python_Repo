class Node:
    def __init__(self,data):
        self.data = data
        self.next = None

class Stack:
    def __init__(self):
        self.top = None

    def insertAtBottom(self,item):
	print "New Stack: \n", item
        if self.isEmpty():
	    print "Push Element: ", item
            self.push(item)
        else:
            temp = self.pop()
	    print "Popped Elements: --->\n", temp
            self.insertAtBottom(item)
            self.push(temp)

    def reverse(self):
        if not self.isEmpty():
            temp = self.pop()
# 	    print "===>", temp
            self.reverse()
	    print "New Stack to be passed: \n", temp
            self.insertAtBottom(temp)
 

    def push(self,new_data):
        new_node = Node(new_data)
        new_node.next = self.top
        self.top = new_node

    def pop(self):
        value = self.top.data
#	print "Value: ", value
        self.top = self.top.next
        return value

    def printStack(self):
        temp = self.top
        while(temp):
            print "%d" % temp.data
            temp = temp.next

    def isEmpty(self):
        if(self.top == None):
            return True
        else:
            return False


s= Stack()
s.push(1)
s.push(2)
s.push(3)
s.push(4)
s.push(5)
s.push(6)
s.push(7)

print "Original Stack :"
s.printStack()

s.reverse()

print "Stack After Reversal: "
s.printStack()
