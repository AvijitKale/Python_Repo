class Queue(object):
    def __init__(self):
        self.head = 0
        self.tail = 0
        self.n = 0
        self.l = []
     
    def enqueue(self, element):
        # this will create a lot of wasted space. Use something like
        # linked list
        self.l.append(element)
        self.tail += 1
        self.n += 1
     
    def dequeue(self):
        if self.n == 0: return None
        e = self.l[self.head]
        self.head += 1
        self.n -= 1
        return e
         
    def size(self):
        print self.n
     
    def print_elements(self):
        return [self.l[i] for i in xrange(self.head, self.tail)]


q = Queue()

q.enqueue(1)
q.enqueue(2)
q.enqueue(3)
q.enqueue(4)
q.enqueue(5)

list1 = q.print_elements()

print list1

print "Size of the queue: "

q.size()

dq1 = q.dequeue()

print "Dequeued Element from the queue: "
print dq1 

list1 = q.print_elements()


print "New Queue: ", list1

print "Size of the queue: "

q.size()


