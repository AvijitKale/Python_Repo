def selectionSort(alist):
   for fillslot in range(len(alist)-1,0,-1):
       positionOfMax=0
       print "--->",fillslot
       for location in range(1,fillslot+1):
	   print "===>",alist[location]
	   print "***>",alist[positionOfMax]
           if alist[location]>alist[positionOfMax]:
               positionOfMax = location

       temp = alist[fillslot]
       alist[fillslot] = alist[positionOfMax]
       alist[positionOfMax] = temp
       print "===>>", fillslot, alist[fillslot]
       print "\n"

alist = [54,26,93,55,10,3,12,20]
selectionSort(alist)
print(alist)
