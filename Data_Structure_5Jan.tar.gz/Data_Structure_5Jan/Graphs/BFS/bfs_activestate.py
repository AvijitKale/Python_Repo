
def BFS(graph,start,end):
	queue = []
		
	temp_path = [start]
	
	queue.append(temp_path)                 ## Actually USE enqueue operation of queue here
	
	while len(queue) > 0:                    ## Actually USE isEmpty operation of queue here
		tmp_path = queue.pop()           ## Actually USE dequeue operation of queue here 
		last_node = tmp_path[-1]
		print "last_node: ", last_node
		print "tmp_path: ", tmp_path
		if last_node == end:
			print "=====> VALID_PATH : ",tmp_path
		for link_node in graph[last_node]:
			if link_node not in tmp_path:
				new_path = []
				new_path = tmp_path + [link_node]
				print "new_path: ", new_path
				queue.append(new_path)           ## Actually USE enqueue operation of queue here
				print "--> Q: ", queue


graph = {'A': ['B', 'C','E'],
             'B': ['A','C', 'D'],
             'C': ['D'],
             'D': ['C'],
             'E': ['F','D'],
             'F': ['C']}


BFS(graph,"A","D")
