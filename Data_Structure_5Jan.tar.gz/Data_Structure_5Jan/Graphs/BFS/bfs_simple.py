def BFS(start, target, GRAPH):
	print "Start:",start,"Target:",target
	queue = [start]
	visited = []

	while len(queue) > 0:
		x = queue.pop(0)

		if x == target:
			visited.append(x)
			return visited
		elif x not in visited:
			visited = visited+[x]
		if GRAPH[x] is not None:
		## add nodes at the END of the queue
			queue =  GRAPH[x]+ queue

	return visited


GRAPH = {1 : [2,3], 2:[4,5], 3:[6], 4:None, 5:[7,8], 6:None, 7:None, 8:None}

print "BFS Path: start: 1  target: 7 ",BFS(1,7,GRAPH)

print "\n\nAnother Example: \n\n"

print "BFS Path: start:1 target: 3 ",BFS(1,3,GRAPH)
