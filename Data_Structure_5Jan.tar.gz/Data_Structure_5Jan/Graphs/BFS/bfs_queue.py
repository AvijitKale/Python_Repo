import collections


def breadth_first_search(graph, root): 
    visited, queue = set(), collections.deque([root])
    while queue: 
        vertex = queue.popleft()
        for neighbour in graph[vertex]: 
            if neighbour not in visited: 
                visited.add(neighbour) 
                queue.append(neighbour) 
	return visited

if __name__ == '__main__':

    GRAPH = {1 : [2,3], 2:[4,5], 3:[6], 4:None, 5:[7,8], 6:None, 7:None, 8:None}

    print "BFS Path: start: 1  target: 7 ",breadth_first_search(GRAPH,1)

    graph = {0: [1, 2], 1: [2], 2: []} 
    print (breadth_first_search(graph, 0))
