##Below is a listing of the actions performed upon each visit to a node.
#	
#	Mark the current vertex as being visited.
#	Explore each adjacent vertex that is not included in the visited set.

##   Algo:
'''
		1:  Start with the start vertex of graph
		2:  Push it onto the stack
		3:  Mark it as Visited (Result)
		4:  Look at all the adjusant vertices of A and which are NOT visited
		5:  Start from the adjusant vertex B (which are NOT visited) of A in Alphabetical order
		6:  Push vertex in stack and Mark it as Visited(Result)
		7:  Again look for all the adjusant vertices of B (Which are NOT visited) in alphabetical order
		8:  push C (adjusant of B and which is not Visited either) onto the stack and mark it as visited 
		9:  and so on till we get to the vertex F (suppose) for which there is NO NEW vertex which is NOT visited.
		10: pop out F from the stack and look for below it suppose E . If E also doee not have any vertices which are not Visi			  ted pop out E and look for next on the stack D suppose. Like wise till stack is EMPTY
		11: So DFS result will have all the visited vertices some of them may be pointing to None. But since we have visited 			  them they are there in the Result.
'''

def DFS(start, target, GRAPH):
	print "Source:",start,"Target:",target
	stack = [start]
	visited = []
#	pos = 0

	while len(stack) > 0:
		x = stack.pop(0)

		if x == target:
			visited.append(x)
#			pos += 1
			return visited
		elif x not in visited:
#			visited = visited+[x]
			visited.append(x)
#			pos += 1
#		print "Position: ", pos
		print "Visited: ", visited		
		print "X : {0} Graph:{1} ".format(x,GRAPH[x])
				
		if GRAPH[x] is not None:
			stack = GRAPH[x] + stack
		print "Stack: ", stack
#		if GRAPH[x] is None:
#			visited.remove(x)		
#			y = visited[pos-2]
#			print "Pos -1: stack", y
#			if x in GRAPH[visited[pos-2]]:
#				del visited[pos-2]
	return visited


GRAPH = {1 : [2,3], 2:[4,5], 3:[6], 4:[8], 5:[7,8], 6:None, 7:None, 8:None}


graph1 = {'A': ['B', 'C'],
         'B':  ['A', 'D', 'E'],
         'C':  ['A', 'G'],
         'D':  None,
	 'G':  None,
         'E':  ['B', 'F'],
         'F':  ['C', 'E']}


graph2 = {'A':['B','C'],'B':['F'],'C':['D','E'],'D':['E'],'E':['A','F'],'F':None}


print "DFS Path from 1 to 7: ",DFS(1,7,GRAPH)

print "\n\nAnother Number series example: \n\n"

print "DFS Path from 1 to 3: ",DFS(1,3,GRAPH)

print "\n\n Strings Example:   \n"

print "DFS Path: ",DFS('A','E', graph2) 
