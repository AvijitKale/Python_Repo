graph1 = {'A': ['B', 'C'],
         'B':  ['A', 'D', 'E'],
         'C':  ['A', 'G'],
         'D':  None,
	 'G':  None,
         'E':  ['B', 'F'],
         'F':  ['C', 'E']}


def dfs_path(start, target , PATH):
	print "Start: ", start 
	print "Target: ", target

	stack = [start]
	visited = []

	while len(stack) > 0:
		x = stack.pop()

		if x == target:
			visited.append(x)
			return visited

		elif x not in visited:
			visited = visited + [x]

		print  x, " : PATH == ", PATH[x]

		if PATH[x] is not None:
			stack =  PATH[x] +  stack

		if PATH[x] is None:
			visited.remove(x)

	return visited


print ("PATH: ", dfs_path('A', 'F', graph1))
