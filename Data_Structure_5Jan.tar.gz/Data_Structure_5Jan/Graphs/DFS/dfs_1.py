def dfs_paths(graph, start, goal):
    stack = [(start, [start])]
    visited = []
    while stack:
        (vertex, path) = stack.pop()
        if vertex not in visited:
            if vertex == goal:
                return path
            visited.append(vertex)
            for neighbor in graph[vertex]:
                stack.append((neighbor, path + [neighbor]))


GRAPH = {1 : [2,3], 2:[4,5], 3:[6], 4:None, 5:[7,8], 6:None, 7:None, 8:None}

graph2 = {'A':['B','C'],'B':['F'],'C':['D','E'],'D':['E'],'E':['A','F'],'F':None}


print "DFS Path",dfs_paths(1,7,GRAPH)

print "DFS Path: ",dfs_paths('A','E', graph2)

