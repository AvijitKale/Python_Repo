string = raw_input("Enter the list of items seperated by comma: ")

list1 = [int (x) for x in string.split(',')]

print list1

max_value = list1[0]


Count = len(list1)

while Count:
    for x in list1:
	if x > max_value:
	    max_value = x
    Count  = Count -1

print x
