string  = raw_input("Enter the list seperated by comma: ")

list1 = [int (x) for x in string.split(',')]

print list1


new_list = []

while list1:
    max_value = list1[0]
    for x in list1:
	if x > max_value:
	    max_value = x
    new_list.append(max_value)
    list1.remove(max_value)

print new_list
	
