string = raw_input("Enter the list items(seperated by comma):  ")

list1 = [int(x) for x in string.split(',')]

## Define sum_item = 0 since first time addition will need this value
sum_items = 0

for x in list1:
    sum_items += x

print sum_items


