list1 = [1,3,5,23,87,-45,-3,6,0,73,40,75,61]

new_list = []

while list1:
    minimum = list1[0]
    for x in list1:
        if x < minimum:
            minimum =x
    new_list.append(minimum)
    list1.remove(minimum)


print new_list
