class Node():
    def __init__(self,data):
	self.data = data
	self.next = None


class Stack():
    def __init__(self):
	self.top = None

    def insertAtBottom(self,item):
	if self.isEmpty():
	    self.push(item)
	else:
	    temp = self.pop()
	    self.insertAtBottom(temp)
	    self.push(temp)


    def reverse(self):
        if not self.isEmpty():
            temp = self.pop()
            print temp
            self.reverse()
#        print temp
            self.insertAtBottom(temp)


    def push(self,data):
	temp = self.top
	
	new_node = Node(data)
#	if self.isEmpty():
#	    self.top = new_node
#	else:
        new_node.next = self.top
        self.top = new_node

    def pop(self):
	value = self.top.data
	self.top = self.top.next
	return value
	
   
    def isEmpty(self):
	if self.top == None:
	    return True
	else:
	    return False
#	return self.top == 0
    
    def printStack(self):
	temp = self.top
	while(temp):
	    print temp.data	
	    temp = temp.next

    def insertAtBottom(self,item):
#	print "New Stack: ", self
        if self.isEmpty():
            self.push(item)
        else:
            temp = self.pop()
#	    print "--->", temp
            self.insertAtBottom(item)
            self.push(temp)

#    def reverse(self):
#	if not self.isEmpty():
#            temp = self.pop()
#	    print temp
#            self.reverse()
#            print temp
#	    self.insertAtBottom(temp)
	


s = Stack()

s.push(1)
s.push(2)
s.push(3)
s.push(5)
s.push(10)
s.push(12)

print "Original Stack: "	
s.printStack()

print "Popped element: ", s.pop()

print "Stack Now: "

s.printStack()

s.reverse()

print "Reverse Stack Now: "
s.printStack()
