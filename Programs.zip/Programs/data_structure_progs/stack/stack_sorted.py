class Node():
    def __init__(self,data):
	self.data =  data
	self.next = None

class Stack():
    def __init__(self):
	self.top = None


    def push(self,data):
	curr = self.top

	if curr is None:
	    new_node = Node(data)
#	    new_node.next = curr
	    self.top = new_node
	    return

	if curr.data > data:
	    new_node = Node(data)
	    new_node.next = curr
	    self.top = new_node
	    return

	while curr.next is not None:
	    if curr.next.data > data:
		break
	    curr = curr.next

	new_node = Node(data)
	new_node.next = curr.next
	curr.next = new_node


    def printStack(self):
	curr = self.top
	while(curr):
	    print curr.data
	    curr = curr.next

s = Stack()

s.push(5)
s.push(2)
s.push(3)
s.push(4)
s.push(1)
s.push(10)

s.printStack()




	    
	   
