class Node:
	def __init__(self,data):
		self.data = data
		self.next = None

class LinkedList:
	def __init__(self):
		self.head = None

	def push_node(self,new_data):
		new_node = Node(new_data)
		new_node.next = self.head
		self.head = new_node
	
	def append_node(self,new_data):
		new_node = Node(new_data)
		last = self.head
		while(last.next):
#			print last.data
			last = last.next
		last.next = new_node
		new_node.next = None
		
	def PrintList(self):
		temp = self.head
		while(temp):
			print temp.data
			temp = temp.next
		

llist = LinkedList()

llist.push_node(10)

llist.push_node(20)

llist.append_node(30)

llist.PrintList()


