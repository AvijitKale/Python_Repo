class Cup:
    color = ""
    
    @staticmethod
    def get_cup(cupColor):
	if cupColor == "Red":
	    return RedCup()
	elif cupColor == "Blue":
	    return BlueCup()
	else:
	    return None


class RedCup(Cup):
    color = "Red"

class BlueCup(Cup):
    color = "Blue"


redcup = Cup.get_cup("Red")

#redcup.get_cup("Red")

print "{0} {1}".format(redcup.color,redcup.__class__.__name__)
bluecup = Cup.get_cup("Blue")

#bluecup.get_cup("Blue")
print "{0} {1}".format(bluecup.color, bluecup.__class__.__name__)



