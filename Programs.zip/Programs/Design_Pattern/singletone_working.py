class class_name(object):
    _instance = None
    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(class_name, cls).__new__(cls, *args, **kwargs)
	    cls.y = 10
        return cls._instance


x = class_name()

print x.y

z = class_name()

print z.y



