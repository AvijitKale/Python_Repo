class SingleTone(object):
    __instance = None
    def __new__(cls, *args, **kwargs):
        if SingleTone.__instance is None:
            SingleTone.__instance = super(SingleTone,cls).__new__(cls,*args,**kwargs)
        SingleTone.__instance = val
        return SingleTone.__instance


x = SingleTone(10)

print x.val

y = SingleTone(20)

print y.val
