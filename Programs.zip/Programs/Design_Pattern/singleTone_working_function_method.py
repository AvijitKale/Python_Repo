class MySingleton(object):
    _instance = None
    def __new__(self,*args, **kwargs):
	if not self._instance:
	    self._instance = super(MySingleton,self).__new__(self, *args, **kwargs)
            self.y = 10
        return self._instance


x = MySingleton()

print x.y

x.y = 20

z = MySingleton()


print z.y
print x.y

