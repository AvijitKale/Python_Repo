my_dict = {'a': 1}

if not bool(my_dict):
    print("Dictionary is empty")
else:
    print("Not EMpty")

