my_dict = {'data1':100,'data2':-54,'data3':247}
print(sum(my_dict.values()))
