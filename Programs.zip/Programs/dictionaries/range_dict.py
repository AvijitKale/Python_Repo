string = raw_input("Enter the range of numbers for dict: (seperated by comma)")

range_num = [int(x) for x in string.split(',')]

print range_num

low_range = range_num[0]

high_range = range_num[1]

dic = {}

for x in range(low_range, high_range+1):
    dic[x] = x*x

for k,v in dic.items():
    print k, "=>", v
