import pdb
import boto.ec2
import time

#conn = boto.ec2.connect_to_region("us-west-2")

conn = boto.ec2.connect_to_region("us-west-2",aws_access_key_id='AKIAJUIMWYJXBG57VKYQ',
       aws_secret_access_key= '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')
# 'AKIAJUIMWYJXBG57VKYQ', 'zpQllrxOq34a4usgcIc3gY77Mo/b47SNJOFKqVCL')

#ec2conn = conn.EC2Connection('AKIAJUIMWYJXBG57VKYQ', 'zpQllrxOq34a4usgcIc3gY77Mo/b47SNJOFKqVCL')

print conn

print "*********************************"

reservation = conn.run_instances("ami-9abea4fb",
        key_name="Avijit1-key-pair-uswestog",
        instance_type="t2.micro",
        security_groups=["sg-68f87f0e"])

time.sleep(5)

instance = reservation.instances[0]

print instance
#statuses = ec2conn.get_all_instance_status()

#print statuses


