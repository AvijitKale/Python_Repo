import os
import boto3

# note, in part 2 we will move these to a separate .env file so they
# aren't accidentally published in a public repository.
os.environ["AWS_ACCESS_KEY_ID"] = "AKIAI357QJOBHJXNVX3A"
os.environ["AWS_SECRET_ACCESS_KEY"] = "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"
os.environ["AWS_DEFAULT_REGION"] = "us-west-2"

userdata = """#cloud-config

repo_update: true
repo_upgrade: all

packages:
 - s3cmd

runcmd:
 - echo 'Hello S3!' > /tmp/hello.txt
 - aws --region YOUR_REGION s3 cp /tmp/hello.txt s3://YOUR_BUCKET/hello.txt
"""


ec2 = boto3.resource('ec2')
instances = ec2.create_instances(
    ImageId='ami-f303fb93',         # default Amazon linux
    InstanceType='t2.micro',
    KeyName='Avijit1-key-pair-uswestog',
    MinCount=1,
    MaxCount=1,
#    IamInstanceProfile={
#        'Arn': 'YOUR_ARN_ID'
#    },
    SecurityGroupIds=['sg-79d7501f'],
#    UserData=userdata
)

#for instance in instances:
#    print("Waiting until running...")
#    instance.wait_until_running()
#    instance.reload()
#    print((instance.id, instance.state, instance.public_dns_name,
#instance.public_ip_address))
