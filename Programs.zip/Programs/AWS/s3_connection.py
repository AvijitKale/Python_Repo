
from boto.s3.connection import S3Connection

from boto.s3.connection import Location

import boto.s3

import sys
#c = boto.connect_s3()
#boto.s3.connect_to_region("USWest2")

conn = S3Connection('AKIAJUIMWYJXBG57VKYQ', 'zpQllrxOq34a4usgcIc3gY77Mo/b47SNJOFKqVCL')

print conn
print '\n'.join(i for i in dir(Location) if i[0].isupper())

bucket = conn.create_bucket('avijitbucket',location=boto.s3.connection.Location.DEFAULT)

k = bucket.new_key('abc/123/')
#k.set_contents_from_string('')

for file_key in bucket.list():
    print file_key.name
