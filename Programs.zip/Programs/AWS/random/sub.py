import subprocess
ls_output = subprocess.check_output(['ls'])

