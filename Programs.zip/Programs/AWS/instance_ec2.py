import boto.ec2

#import boto
#ec2 = boto.connect_ec2()




conn = boto.ec2.connect_to_region("us-west-2",
 aws_access_key_id='<AKIAI357QJOBHJXNVX3A>',
 aws_secret_access_key='<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>')

print conn


print "**********************************\n\n"



reservation = conn.run_instances(image_id='<ami-f303fb93>',key_name='Avijit1-key-pair-uswestog',
 instance_type='t2.micro',
 security_groups=['Avijit1_sg_uswestog'])

print "**********************************\n\n"

print reservation

