import pdb
import boto.ec2
import time

conn = boto.ec2.connect_to_region("us-west-2", 
	aws_access_key_id='AKIAJUIMWYJXBG57VKYQ', 
	aws_secret_access_key='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')

print conn

new_reservation = conn.run_instances("ami-9abea4fb",
    key_name="Avijit1-key-pair-uswestog",
    instance_type="t2.micro",
    security_group_ids=["sg-68f87f0e"])

instance = new_reservation.instances[0]

print instance

conn.create_tags([instance.id], {"Name":"avi5-instance"})

while instance.state == 'pending':
    print "Instance state: %s" % instance.state
    time.sleep(10)
    instance.update()

print "Instance state: %s" % instance.state
print "Public dns: %s" % instance.public_dns_name

