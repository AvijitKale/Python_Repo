import pdb
import boto.ec2
import time
import paramiko

from boto.manage.cmdshell import sshclient_from_instance



from boto.s3.connection import S3Connection

ec2conn = boto.ec2.connect_to_region("us-west-2", 
	aws_access_key_id='AKIAJUIMWYJXBG57VKYQ', 
	aws_secret_access_key='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')


reservations = ec2conn.get_all_instances(instance_ids=['i-00ffdbf2be082f82e'])

instance = reservations[0].instances[0]

print instance

public_ip_address = instance.ip_address

print public_ip_address


#ssh = paramiko.SSHClient()
#ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
#ssh.connect(instance.ip_address, username='ec2-user', key_filename=os.path.expanduser('~/.ssh/test'))
#stdin, stdout, stderr = ssh.exec_command('echo "TEST"')
#print stdout.readlines()
#ssh.close()



ssh_client = sshclient_from_instance(instance,
                                     '/Users/yogesh.s/Documents/temp/aws/Avijit1-key-pair-uswestog.pem',
                                     user_name='ubuntu')


status, stdout, stderr = ssh_client.run('ls -al')

print status
print stdout




s3conn = S3Connection('AKIAJUIMWYJXBG57VKYQ', 'zpQllrxOq34a4usgcIc3gY77Mo/b47SNJOFKqVCL')

print s3conn

bucket_name = 'avijit-kale-sample-bucket'

bucketObject = s3conn.lookup(bucket_name)
if bucketObject is None:
	print "No such bucket! creating the bucket : ", bucket_name
	#bucketObject = s3conn.create_bucket(bucket_name, location=Location.USWest2)
else :
 	print "bucket exists, using the same bucket"


#