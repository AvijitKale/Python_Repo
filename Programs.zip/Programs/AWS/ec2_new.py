import boto
ec2 = boto.connect_ec2()

key_pair = ec2.create_key_pair('Avijit1-key-pair-uswestog')  # only needs to be done once
key_pair.save('/.ssh')
reservation = ec2.run_instances(image_id='ami-f303fb93', key_name='ec2-sample-key')

# Wait a minute or two while it boots
for r in ec2.get_all_instances():
    if r.id == reservation.id:
        break
print r.instances[0].public_dns_name 
