import boto.ec2
conn = boto.ec2.connect_to_region("us-west-2")

reservations = conn.get_all_instances()

print reservations

#conn.run_instances(
#    'ami-9abea4fb',
#    key_name='Avijit1-key-pair-uswestog',
#    instance_type='t2.micro',
#    security_groups=['sg-68f87f0e']
#)
