import boto.ec2
import time

#conn = boto.ec2.connect_to_region("us-west-2",
# aws_access_key_id='<my-key>',
# aws_secret_access_key='<my-secret-key>')

dev_sda1 = boto.ec2.blockdevicemapping.EBSBlockDeviceType()
dev_sda1.size = 1 # size in Gigabytes
bdm = boto.ec2.blockdevicemapping.BlockDeviceMapping()
bdm['/dev/sda1'] = dev_sda1     


c = boto.connect_ec2('AKIAI357QJOBHJXNVX3A', '+U4r9aKJEqiBG6r+lWC8AzwaiFgWMXbMKLAXmr9t')
#image = c.get_image('ami-f303fb93')

print c


#image = conn.get_image('amzn-ami-hvm-2016.03.2.x86_64-gp2 (ami-f303fb93)')

#conn = boto.ec2.connect_to_region("us-west-2")

#conn.get_all_reservations()
#
params = c.get_params()


print params


reservation = c.run_instances( image_id='ami-f303fb93', 
                                 key_name='Avijit1-key-pair-uswestog', 
                                 instance_type='t2.micro',
                                 security_groups = [ 'Avijit1_sg_uswestog', ]
                                 block_device_mappings = bdm)

#time.sleep(4)
#
#reservation = image.run(
##    'ami-f303fb93',
#    key_name='Avijit1-key-pair-uswestog',
#    instance_type='t2.micro',
#    security_groups=['Avijit1_sg_uswestog']
#)
#
#instance = reservation.instances[0]
#c.create_tags([instance.id], {"Name": instance_name})

#instance = conn.get_all_instances()

#instance = conn.get_all_instances(instance_ids=['i-09d631c7cf0e457b8'])
#print instance[0].instances[0].start()
