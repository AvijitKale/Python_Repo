
import boto3


ec2 = boto3.resource('ec2',)

ec2_connection = boto.connect_ec2()

c = boto.connect_ec2('AKIAI357QJOBHJXNVX3A', '+U4r9aKJEqiBG6r+lWC8AzwaiFgWMXbMKLAXmr9t')

print c

#ec2 = boto.resource('ec2')
instances = c.create_instances(
    ImageId='ami-f303fb93',         # default Amazon linux
    InstanceType='t2.micro',
    KeyName='Avijit1-key-pair-uswestog',
    MinCount=1,
    MaxCount=1,
#    IamInstanceProfile={
#        'Arn': ''
#    },
    SecurityGroupIds=['Avijit1_sg_uswestog'],
#    UserData=userdata
)
