import telnetlib
import time


#user = "amcc"
#password = "amcc01"

command = "dd if=/dev/zero of=avi123.img bs=100 count=1"

class telnet_host(object):
    def __init__(self,ip,user,password):
	self.ip = ip
	self.user = user
	self.password = password

    def connect(self):
        self.tnA = telnetlib.Telnet(self.ip)
        self.tnA.read_until('username: ', 3)
        self.tnA.write(self.user + '\n')
        self.tnA.read_until('password: ', 3)
        self.tnA.write(self.password + '\n')
        self.tnA.read_until('amcc@amcc-sqasiddhesh-T3400:~$', 3)
        self.tnA.write(command + '\n')
        return self.tnA

    def quit_telnet(self):
	self.tnA.write("bye\n")
	self.tnA.write("quit\n")

tn_A =  telnet_host("10.48.12.192","amcc", "amcc01")

#tn_B = telnet_host("10.48.12.81")

output = tn_A.connect()

time.sleep(4)
tn_A.quit_telnet()
