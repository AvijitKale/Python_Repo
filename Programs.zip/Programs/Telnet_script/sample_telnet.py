import threading
import telnetlib
import datetime
import sys
# Global Variable Declarations
TIMEOUT = 30
USER = "amcc"
PROMPT = "$#"
PASSWORD = "amcc01"
COMMAND = "ls -ltr"

class listener(object):
    def __init__(self, filename, ip):
        # Have to make a call to the super classes' __init__ method
#        super(listener, self).__init__()
        self.f = open(filename,"a")
        try:
            self.tn = telnetlib.Telnet(ip, 23, TIMEOUT)
        except:
            print "Bad Connection"
            sys.exit(0)

    def run(self):
        # login
        e = self.tn.read_until("Login: ")
        self.tn.write(USER+"\n")
        # and password
        e = self.tn.read_until("Password: ")
        self.tn.write(PASSWORD+"\n")
	
	e = self.tn.read_until(":~# ")
        self.tn.write(COMMAND+"\n")

if __name__ == "__main__":
    # Things to listen to is a dictionary of hosts and files to output
    # to, to add more things to listen to just add an extra entry into
    # the things_to_listen_to in the format: host : outputfile
    output = listener("output.txt","10.48.12.192")
    # Thread holder is going to hold all the threads we are going to

    print output
