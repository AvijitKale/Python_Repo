fh = open ("testfile.txt")

#line = fh.readline()

for x in fh:
    print (x)

fh.close()


