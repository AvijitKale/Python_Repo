f1 = open("testfile.txt","r")

s = f1.readlines()

s.reverse()

f1.close()


f2 = open ("reversefile.txt", "w+")

for line in s:
    f2.write(line)

f2 = open ("reversefile.txt", "r")

for l in f2:
    print l

f2.close()



