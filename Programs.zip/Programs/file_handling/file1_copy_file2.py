## r+ mode is for both read write



file1_h = open ("testfile.txt", "r")

s = file1_h.readlines()

file1_h.close()




file2_h = open ("copyfile.txt", "w+")


for line in s:
    file2_h.write(line)

file2_h =  open ("copyfile.txt")
for l in file2_h:
     print l

file2_h.close()    

