string = raw_input("Enter the string: ")

list = ["am", "are", "is", "was", "were", "have", "had", "will", "shall"]

spec_words = []

for word in string.split():
    for item in list:
        if (item == word):
	    spec_words.append(item)
	    

print (spec_words)
