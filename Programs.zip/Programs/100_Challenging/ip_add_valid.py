ipadd = raw_input("Enter the IP address to be validated: ")


list1 = []

flag = True

for x in ipadd.split('.'):
    list1.append(x)

print list1

if len(list1) != 4:
    print "Not in range of length Hence given IP address is not Valid"

if len(list1) == 4:
    for x in list1:
        if not x.isdigit():
	    print "%s is Not Digit Hence given IP address is not Valid" % x
	    flag = False
	    break
        i = int(x)

	if i < 0 or i > 255:
	    print "out of range Hence given IP address is not Valid"
	    flag = False
	    break

if len(list1) == 4 and flag == True:
	print "Valid IP Address"

