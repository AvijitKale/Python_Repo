import math

pos = [0,0]

while True:
    s = raw_input()

    if not s:
         break

    movement = s.split(" ")

    direction  = movement[0]

    step = int(movement[1])

    if direction=="UP":
        pos[0] += step

    elif direction == "DOWN":
        pos[0] -= step

    elif direction == "LEFT":
        pos[1] -= step

    elif direction == "RIGHT":
        pos[1] += step

    else:
        pass


print int(round(math.sqrt(pos[0]**2+pos[1]**2)))



