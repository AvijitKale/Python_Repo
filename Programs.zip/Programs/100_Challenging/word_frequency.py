line = raw_input()

freq = {}

for word in line.split():
    if word in freq:
	freq[word] += 1
    else:
	freq[word] = 1


for k in sorted(freq.keys()):
     print k, "=>", freq[k]


