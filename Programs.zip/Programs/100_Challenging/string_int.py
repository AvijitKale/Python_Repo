string =  raw_input()

print string

list1 = []

for x in string.split(','):
    list1.append(int(x))

list1.sort()

list2 = [int(x) for x in string.split(',')]

print list2

print list1
