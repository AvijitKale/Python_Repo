email = raw_input()

list1 = []

list1 = email.split('@')

#for x in email.split():
#    list1.append[x]

print "user name: ", list1[0]
print "company:", list1[1]
