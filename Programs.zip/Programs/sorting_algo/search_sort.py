def search_sort(alist):
     for fillspot in range(len(alist)-1,0,-1):
	 positionMax = 0
	 print "-->", fillspot
	 for location in range(1,fillspot+1,1):
	     print "==>>", alist[location]
	     print "***>", alist[positionMax]
	     if(alist[location]> alist[positionMax]):
	         positionMax = location
         temp = alist[fillspot]
         alist[fillspot] = alist[positionMax]
         alist[positionMax] = temp
         print "+++>", alist,"\n"

alist = [10,98,23,65,6,47]
search_sort(alist)
print alist
