def binary_search(alist,item):
        
    print "Length of the list: ", len(alist)
    print "Item to be searched: ", item
    found = False
    bottom = 0
    top = len(alist)-1
    while(bottom <= top and found is False):
	middle = (bottom + top) // 2
#	print alist[middle]
#	print alist[top]
#	print alist[bottom]
        if alist[middle] == item:
	    found = True
	else:
            if alist[middle] > item:
	        top = middle -1
	    elif alist[middle] < item:
	        bottom = middle +1
    return found

alist = [-23,-19,-11,-6,1,3,6,23,45,67,70,81,84,93,109]
isitfound = binary_search(alist,67)

if isitfound == True:
    print "Item Found"
else:
    print "Item NOT Found"
