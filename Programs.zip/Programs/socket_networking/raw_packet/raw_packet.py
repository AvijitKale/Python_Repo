#!/usr/bin/env python
from socket import socket, AF_PACKET, SOCK_RAW
s = socket(AF_PACKET, SOCK_RAW)
s.bind(("eth0", 0))

# We're putting together an ethernet frame here, 
# but you could have anything you want instead
# Have a look at the 'struct' module for more 
# flexible packing/unpacking of binary data
# and 'binascii' for 32 bit CRC
src_addr = "10.48.12.132"

print src_addr,"\n"


dst_addr = "10.48.12.192"

print dst_addr, "\n"

payload = ("["*30)+"PAYLOAD"+("]"*30)

print payload, "\n"

checksum = "1000000"

print checksum, "\n"

ethertype = "00004"

print ethertype,"\n"

packet = dst_addr+src_addr+ethertype+payload+checksum

print packet, "\n"

s.send(dst_addr+src_addr+ethertype+payload+checksum)
