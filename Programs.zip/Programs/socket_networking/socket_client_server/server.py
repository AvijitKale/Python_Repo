import socket

sock = socket.socket()

host = socket.gethostname()

print "*"*4,host

port = 1234

sock.bind((host,port))

sock.listen(5)

while True:
    c, addr = sock.accept()
    print "Got connection from: ", addr
    c.send ("Thank you for accepting")
    c.close()


