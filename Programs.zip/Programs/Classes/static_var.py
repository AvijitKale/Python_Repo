class Test(object):
    __count  = 0

    def A(self):
#	self._Test__count = count
	__count = __count +1
	return __count
    


t = Test()

Test.__count = 1
print Test.__count

print t.A()
print t.__count 

print Test.__count
