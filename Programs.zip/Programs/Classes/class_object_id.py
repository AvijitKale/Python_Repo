class A(object):
    pass

a = A()

b = A()

if id(a) == id(b):
    print "True"

else:
    print "False"

print "IDs of objects: ", id(a) , id(b)

print (a, b)
