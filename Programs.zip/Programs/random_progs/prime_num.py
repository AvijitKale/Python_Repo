lower_num = int(raw_input("Enter the lower number:"))
upper_num = int(raw_input ("Enter the upper number:"))

for num in range (lower_num, upper_num+1):
    if num > 1:
        for i in range(2,num):
            if (num % i)== 0:
	        print "number is not prime"
	        break
        else:
            print num	
	  
