a = 0
b = 1

num = int(raw_input("Enter the number for fabonicci series:" ))
print a
print b

while(num>1):
    c = a+b
    a = b
    b = c
    num -= 1
    print c


