a=[1,2,3,4,5,6,7,2,3,4]

d = {}


for elem in a:
    if elem in d:
        d[elem] = d[elem] +1
    else:
	d[elem] = 1


for k,v in d.items():
    if v == 1:
	print k


