string =  raw_input("Enter the string words to be reversed: ")

list1 = [x for x in string.split(' ')]

count = len(list1)

print count

print list1

new_string = []

while(count):
    count = count -1
    print list1[count]
    new_string.append(list1[count])

print ' '.join(new_string)
