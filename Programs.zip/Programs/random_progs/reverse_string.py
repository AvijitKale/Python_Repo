string = raw_input("Enther the string to be reversed: ")

count  =  len(string)

new_string = []
while(count):
    count =  count -1
    print string[count]
    new_string.append(string[count])

print ''.join(new_string)

