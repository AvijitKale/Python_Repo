a = ['a', 'b', 'c', 'd']
b = ['c', 'x', 'g', 'h']
c = ['1', 'z', 'c', 'd']
d = ['1', '1', '3', '4']

print list(set().union(a, b, c, d))
