import os

for i in os.listdir(os.getcwd()):
	print i
