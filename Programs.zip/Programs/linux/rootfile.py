import os
from fabric.api import local,sudo,cd
import subprocess
#from fabric.api import cd,sudo


#subprocess.call(shlex.split('sudo mkdir /etc/x'))

subprocess.call(["sudo", "cd", "/etc"]);
#os.system("sudo sh -c cd /etc; ls -ltr ")

