class Node:
    def __init__(self,data):
	self.data =  data
	self.next =  None

class LinkedList:
    def __init__(self):
	self.head = None

    def push(self, new_data):
	new_node = Node(new_data)
	new_node.next = self.head
	self.head = new_node
	
    def deletePos(self, position):
	temp = self.head
		
	if self.head is None:
	    return

	if (position == 0):
	    self.head = temp.next
	    temp =  None
	    return

	for i in range(position-1):
	    temp = temp.next
	    if temp is None:
	        break
		
	    if temp is None:
	        return

	    if temp.next is None:
	        return
		
		# Node temp.next is the node to be deleted
	        # store pointer to the next of node to be deleted
	    new_temp = temp.next.next
	    temp.next = None
	    temp.next = new_temp

    def ListLen(self):
        temp = self.head
	count = 0
	while (temp):
	    temp = temp.next
	    count = count + 1
        return count
	
    def getCount(self):
        temp = self.head # Initialise temp
        count = 0 # Initialise count

        	# Loop while end of linked list is not reached
        while (temp):
            count += 1
            temp = temp.next
        return count
		 	
	
    def printList(self):
        temp = self.head
	while(temp is not None):
	    print "%d" %(temp.data)
	    temp = temp.next


llist = LinkedList()

llist.push(10)
llist.push(8)
llist.push(4)
llist.push(5)
llist.push(7)
llist.push(11)
count = llist.ListLen()

print "Count of List:%d" % count

llist.printList()

print "deleting position 1\n"

llist.deletePos(1)


print "List after deletion:\n"

llist.printList()

print "deleting 0th pos:\n"
llist.deletePos(0)	

print "list after deleting 0th pos:\n"

llist.printList()	
