class A(object):
    class_var = 10

    def __init__(self,i_var):
	self.i_var = i_var



a = A(2)

b = A(3)

print a
 
print b

print "a.i_var", a.i_var

print "b.i_var", b.i_var

print "a.class_var", a.class_var

print "b.class_var", b.class_var
