def left_shift(self,n):
    for i in range(n):
	temp = self[-1]	    
	count = len(self)-1
#	print count
	astring = self[0:count]
        new_string = temp + astring 
	self = new_string
	print "After %d iteration: string is %s " %(i+1, new_string)
    return new_string


astring = raw_input("Enter the string: ")
print left_shift(astring,2)
