astring = raw_input("Enter the string: ")

for x in list(astring):
    print x
    
