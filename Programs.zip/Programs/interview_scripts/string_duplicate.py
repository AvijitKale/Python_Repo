astring = raw_input("Enter the string : ")

for x in range(len(astring)):
    print astring[x]
    for y in range(x+1,len(astring)):
	print astring[y]
	if astring[x] == astring[y]:
	   print "Duplicate: ", astring[x], astring[y]



