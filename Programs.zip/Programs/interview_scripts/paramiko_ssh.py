import paramiko
ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(
    paramiko.AutoAddPolicy())
ssh.connect('10.48.12.192', username='root', 
    password='amcc01',allow_agent=True)
stdin, stdout, stderr = ssh.exec_command(
    "dmesg")
print stdout
