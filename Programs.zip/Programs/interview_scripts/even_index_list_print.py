list1 = [1,3,5,7,10,23,46,90]

# This will print ONLY the EVEN Indices numbers in the list
# e.g  index 0,2,4,6,8,10
# above list has 0=>1 2=>5 4=>10 6=>46

list2 = [x for x in list1[::2] ]

print list2



