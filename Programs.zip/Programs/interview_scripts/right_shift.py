def right_shift(self,n):
    for i in range(n):
#	string = self
        string = self[1:]
        string += self[0]
        self = string	

    return string

astring = "avijit"

print right_shift(astring, 2)
