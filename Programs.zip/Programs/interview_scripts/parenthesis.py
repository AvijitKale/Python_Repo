from pythonds.basic.stack import Stack


def balanced_parenthesis(symbolstring):
	s = Stack()
	flag_balance = True
	index = 0
	r_cnt = c_cnt = s_cnt = 0

	while index < len(symbolstring) and flag_balance:
		symbol = symbolstring[index]
		if (symbol == "(" or symbol == "{" or symbol == "["):
			if symbol == "(":
				s.push(symbol)
				r_cnt += 1	
#				print "Stack: ", s
			elif symbol == "{":
                                s.push(symbol)
                                c_cnt += 1
#                                print "Stack: ", s
			elif symbol == "[":
                                s.push(symbol)
                                s_cnt += 1
#                                print "Stack: ", s
	
		elif (symbol == ")" or symbol == "}" or symbol == "]"):
			if s.isEmpty():
				flag_balance = False
			elif symbol == ")" and r_cnt > 0:
				s.pop()
			elif symbol == "}" and c_cnt > 0:
				s.pop()
			elif symbol == "]" and s_cnt > 0:
				s.pop()
			else:
				flag_balance = False
		else:
			if symbol == " ":
				pass
			else:
				pass

		index = index + 1

	if flag_balance and s.isEmpty():
		return True
	
	else:
		return False


print balanced_parenthesis('((()))')


print balanced_parenthesis('((((())))')	

print balanced_parenthesis('{ { {{} } } }')

print balanced_parenthesis('[a [ b [ cd ] e ] f ]')

print balanced_parenthesis('{( ([ [ {} ) ] {} )]() }')
