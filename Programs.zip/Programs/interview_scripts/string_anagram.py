string1 = raw_input("Enter the string: ")

string2 = raw_input("Enter the string to be checked for anagram: ")


for x in list(string2):
    print x
    flag = False
    for y in list(string1):
	print y
	if x == y:
	    flag = True


if flag == True:
    print "String2 is anagram of String1 "
