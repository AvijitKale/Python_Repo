list = ['a', 'b', 'c', 'd', 'e']
print list[10:]

print list[1:4]
