def greet(name):
    return "Hello "+ name
    

def caller_fun(fun):
    print "I am inside caller function"

    other_name = "John"
    return fun(other_name)


var = caller_fun(greet)

print var
