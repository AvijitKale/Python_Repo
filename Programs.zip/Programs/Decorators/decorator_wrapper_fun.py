def p_decorate(func):
    def func_wrapper(name):
	return "<p>{0}</p>".format(func(name))
    return func_wrapper

@p_decorate
def get_text(name):
    return "inside a wrapper function Hello {0}  wrapper".format(name)

print get_text("John")

