def greet(name):
    print "Hello", name

greet_someone = greet

print greet_someone("John")

greet_other = greet("Harry")

print greet_other
