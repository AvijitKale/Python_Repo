def division(func):
    def func_wrapper(name):
	return "<div>{0}</div>".format(func(name))
    return func_wrapper


def strong(func):
    def func_wrapper(name):
	return "<strong>{0}</strong>".format(func(name))
    return func_wrapper


def id_fun(func):
    def func_wrapper(name):
	return "<id>{0}</id>".format(func(name))
    return func_wrapper



@id_fun
@division
@strong
def get_text(name):
    return "i am same like wrapper function Hello {} how are you".format(name)


print get_text("John")
