def greet(name):
   return "Hello " + name 

def call_func(func):
    other_name = "John"
    return func(other_name)  

print call_func(greet)

print "\n By assigning call_func to variable and then calling variable: "

var = call_func(greet)

print var


# Outputs: Hello John
