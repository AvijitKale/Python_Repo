def outer_fun(msg):
    def inner_fun():
	print msg
    return inner_fun

var = outer_fun("hello")

print var  ### Prints the inner_fun address
print var()  ## prints actual message
