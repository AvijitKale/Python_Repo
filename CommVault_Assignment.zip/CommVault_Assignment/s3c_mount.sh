#!/bin/bash

curr_dir=$(pwd)
echo "The current working directory $curr_dir"
access_key="AKIAJUIMWYJXBG57VKYQ"
secret_key="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"

sudo apt-get update

sudo apt-get install -y python-pexpect

sudo apt-get --yes --force-yes install build-essential libfuse-dev libcurl4-openssl-dev libxml2-dev mime-support automake libtool

echo "\n\nDownloading s3fs-fuse tar.gz\n\n"

wget https://github.com/s3fs-fuse/s3fs-fuse/archive/v1.77.tar.gz

mv v1.77.tar.gz s3fs-fuse-1.77.tar.gz

tar zxvf s3fs-fuse-1.77.tar.gz

cd s3fs-fuse-1.77/

./autogen.sh

./configure --prefix=/usr

echo "\n\ninstalling s3fs-fuse\n\n"

make

sudo make install

echo "\n\nDownloading s3fs tar.gz\n\n"

cd ..

wget http://s3fs.googlecode.com/files/s3fs-1.61.tar.gz

tar -xzf s3fs-1.61.tar.gz

cd s3fs-1.61

./configure --prefix=/usr/local

echo "\n\ninstalling s3fs\n\n"

make

sudo make install

echo $access_key:$secret_key > ~/.passwd-s3fs

chmod 600 ~/.passwd-s3fs

mkdir $curr_dir/test_mount

echo "\n\n mounting s3fs...\n\n"

sudo s3fs -o allow_other -o umask=0002 avijit-kale-sample-bucket /home/ubuntu/test_mount 

export PKG_CONFIG_PATH=/usr/lib/pkgconfig:/usr/lib64/pkgconfig/

mount | tee -a "/home/ubuntu/mount_log.txt"

echo "\n\n checking whether s3fs is mounted or not...\n\n"


while read line
do
    if echo $line | grep -Eq 'type fuse.s3fs'
    then
          echo 's3fs mounting Successful'
    fi

done < $curr_dir/mount_log.txt

mkdir $curr_dir/test_mount/test_result

cd $curr_dir/test_mount/test_result



rm -rf *

sudo python /home/ubuntu/file_operations.py
