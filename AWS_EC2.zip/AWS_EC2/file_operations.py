import io
import csv
import os
import time
import subprocess
import commands

filename = "testfile.txt"
Result_File = "IOresult.csv"

mydict = {}


def testresult(testcase, timevalue):
    if mydict.has_key(testcase):
        mydict[testcase].append(timevalue)
    else:
        mydict[testcase] = [timevalue]

cmd = "dd if=/dev/zero of=image_zero bs=10K count=10000 2>&1 | awk '/copied/ {print $8 " " $9}'"
status, output = commands.getstatusoutput(cmd)
testcase1 = "Test: Creating_file:"
testresult(testcase1,output)



cmd = "dd if=/dev/urandom of=image_random bs=10k count=10000 2>&1 | awk '/copied/ {print $8 " " $9}'"
status, output = commands.getstatusoutput(cmd)
testcase1 = "Test: Random Write"
testresult(testcase1,output)





cmd = "dd if=image_random of=/dev/null 2>&1 | awk '/copied/ {print $8 " " $9}'"
status, output = commands.getstatusoutput(cmd)
testcase1 = "Test: Random Read"
testresult(testcase1,output)



start = time.time()
cmd= "rm -rf image.img"
testcase4 = "Deleting Time:"
end  = time.time()
testcase1 = "Test: Delete File"
timevalue1 = end -start
size = os.path.getsize('image_zero')
#print size
size = ((size)/1000000)/timevalue1
output =  "%d%s" % (size/1000,"GBps")
testcase1 = "Test: Delete File"
testresult(testcase1,output)



outfile = open( Result_File, 'w+' )

for key, value in sorted( mydict.items() ):
        outfile.write( str(key) + '\t\t' + str(value) + '\n' )

            
