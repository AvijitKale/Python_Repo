import pdb
import boto.ec2
import time
import paramiko
import os
import pexpect

from boto.manage.cmdshell import sshclient_from_instance
from boto.s3.connection import S3Connection
from arguments import *

instance_id_num = 0
conn = 0
instance = 0

def connect_ec2():
	
	conn = boto.ec2.connect_to_region(region_name, 
			aws_access_key_id = aws_access_id, 
			aws_secret_access_key = aws_secret_key)

	print conn
	return conn

def create_instance():

	new_reservation = conn.run_instances(ec2_image,
						key_name = ec2_key_pair,
						instance_type= ec2_instance_type,
						security_group_ids=[ec2_security_group_id])

	instance = new_reservation.instances[0]

	print instance

	instance_id_num = instance.id

	conn.create_tags([instance_id_num], {"Name":"avi2-instance"})

	while instance.state == u'pending':
		print "Instance state: %s" % instance.state
		time.sleep(10)
		instance.update()
	print "Instance state: %s" % instance.state
	print "Public dns: %s" % instance.public_dns_name	
	
	return (instance, instance_id_num,instance.public_dns_name)

def create_s3_bucket():
	print "\n\n Creating bucket........\n\n"

        time.sleep(30)

        s3conn = S3Connection(aws_access_id ,aws_secret_key)

        print s3conn

        bucket_name = my_bucket

        bucketObject = s3conn.lookup(bucket_name)

        if bucketObject is None:
                print "No such bucket! creating the bucket : ", bucket_name
                bucketObject = s3conn.create_bucket(bucket_name)   # location=Location.USWest2)
        else :
                print "bucket exists, using the same bucket"
        return s3conn

def ssh_instance():
        print "\n\n Creating ssh client \n\n"


        ssh_client = sshclient_from_instance(instance,
                                            ec2_key_pair_name,
                                            user_name = ec2_user_name)


        scp_client = boto.manage.cmdshell.sshclient_from_instance(instance,
                                             ec2_key_pair_name,
                                             user_name = ec2_user_name)

        scp_client.put_file(local_mount_file, VM_mount_file)

        scp_client.put_file(local_IO_file, VM_IO_file)

        print "\n\n installing prerequisite for mounting the s3fs....\n\n"


	
	status, stdout, stderr = ssh_client.run('sudo rm -rf /var/cache/apt/archives/')

        print status
        print stdout

        status, stdout, stderr = ssh_client.run('sudo rm -rf /var/lib/dpkg/lock')

	print status
	print stdout

	status, stdout, stderr = ssh_client.run('ls -ltr')

	print status
	print stdout

	time.sleep(3)

	print "\n\n mounting s3fs on ec2 instance.. please wait...\n\n"


	status, stdout, stderr = ssh_client.run('sh s3fsmount.sh')

	print status
	print stdout

	print "\n\nCopying csv file from ec2 to local machine\n\n"

	command = "scp -i %s ubuntu@%s:%s/*.csv ." % (ec2_key_pair_name,instance.public_dns_name,"/home/ubuntu/test_mount/test_result")
	os.system(command)

	


conn = connect_ec2()
(instance,instance_id_num,instance.public_dns_name) = create_instance()
s3conn = create_s3_bucket()
ssh_instance()

