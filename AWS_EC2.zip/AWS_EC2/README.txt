README:

1. There are 5 files :  
	. arguments.py
	. create_instance_bucket.py
	. file_operations
	. s3c_mount.sh
	. Avijit1-key-pair-uswestog.pem  (this is the key-pair for ec2 instance)

1a::  a. First of all make one directory on your system.
      b. Copy all above files in this directory
      c. Give executable permissions to s3c_mount.sh	

	 
2. Installations needed for running the script:
	. You can use pip to install the latest released version of boto:

	    pip install boto
	
	. Installing pip on ubuntu :
		sudo apt-get update
		apt-get -y install python-pip

	. Install paramiko 
		sudo apt-get install python-paramiko


3. Running the script:
	
	.  Go the directory which you created in the first step
	.  run the command python create_instance_bucket.py on the terminal
	.  If you want to change the arguments given in the file you can go to arguments.py
	.  Suppose you want to change the bucket name used in the program go to arguments.py and locate my_bucket variable.
	   change the name of the bucket.


4. Variables used in the scripts

	. region_name =   Needed for creating the instance e.g uswest2
	. aws_access_id = for this Access key which you get when you create instance manually you have to create an account on AWS amazon.
	. aws_secret_key = for this Secret key which you get when you create instance manually you have to create an account on AWS amazon.
	. ec2_image =   I have used ubuntu image (can change the image id for different images)
	. ec2_key_pair =  Key Pair name which you get after creating an instance on  (*.pem file)
	. ec2_instance_type = i am using t2.micro which is free
	. ec2_security_group_id =  default group 	
	. ec2_key_pair_name = 	 Full directory path of *.pem file
	. ec2_user_name =    In my case it is "ubuntu"



5.  What Script does:
	
	. When you run the command "python create_instance_bucket.py" on the terminal :
		. First it creates an ec2 instance on amazon aws
		. Then using this instance it creates s3 bucket.
		. After the s3 bucket creation using ssh client script mounts S3 storage with FUSE on EC2 Instances.
		. After the successful mounting of s3fs on VM, script creates folder inside storage volume and then executes the file test cases (Performances of 		          creating file, reading file, deleting file) are run on the mounted storage	          
		. AFter the completion of the test cases execution IOresult.csv file is created.
		. Then this csv file is copied (using scp client) into the local machine from where you had run the script.
		