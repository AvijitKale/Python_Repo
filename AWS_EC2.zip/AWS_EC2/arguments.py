## This file has all the arguments

import os

region_name = "us-west-2"
aws_access_id = "AKIAJUIMWYJXBG57VKYQ"
aws_secret_key = "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"

ec2_image = "ami-9abea4fb"
ec2_key_pair = "Avijit1-key-pair-uswestog"
ec2_instance_type = "t2.micro"
ec2_security_group_id = "sg-79d7501f"


ec2_key_pair_name =  os.getcwd() + '/Avijit1-key-pair-uswestog.pem'

ec2_user_name = 'ubuntu'
my_bucket = 'avijitsample-bucket'

local_mount_file = os.getcwd() + '/s3c_mount.sh'
local_IO_file =  os.getcwd() + '/file_operations.py'


VM_mount_file = 's3fsmount.sh'
VM_IO_file = 'file_operations.py'

