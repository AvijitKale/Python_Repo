class Node:
    def __init__(self,value):
	self.value = value
	self.next = None

class Queue:
    def __init__(self):
	self.length = 0
	self.front = None

    def is_empty(self):
	if self.length == 0:
	    print "Empty Queue"
	else:
	    print "Not Empty"

    def enqueue(self,value):
	node = Node(value)
	if self.front == None:
	    self.front = node
	else:
	    last = self.front
	    while last.next:
		last = last.next
	    last.next = node
	self.length += 1

    def dequeue(self):
	value = self.front.value
	self.front = self.front.next
	self.length -= 1
	print value


    def print_queue(self):
	temp =  self.front
	while temp:
	    print "%d" % temp.value
	    temp = temp.next


q = Queue()

q.enqueue(1)
q.enqueue(2)
q.enqueue(3)
q.enqueue(4)

print "Dequeued Value : "
q.dequeue()

q.is_empty()

#print dq1 

print "Current queue: "

q.print_queue()
	    
	
