class Node:
    def __init__(self,cargo):
    	self.cargo = cargo
    	self.next =  None

class queue:
    def __init__(self):
	self.length = 0
	self.head = None

    def is_empty(self):
	return (self.length == 0)

    def enqueue(self,cargo):
#	print "%d" % value
	node = Node(cargo)
	node.next = None
	if self.head == None:
	    self.head = node
	else:
	    last = self.head
	    while last.next:
	        last = last.next
                last.next = node
	self.length += 1
#	print self.length

    def remove(self):
        cargo = self.head.cargo
        self.head = self.head.next
        self.length -= 1
        return cargo

    def print_queue(self):
	temp = self.head
	while temp:
	    print "%d" % temp.cargo
	    temp =  temp.next
    

q = queue()

q.enqueue(1)
q.enqueue(2)
q.enqueue(3)
q.enqueue(4) 




q.print_queue()

