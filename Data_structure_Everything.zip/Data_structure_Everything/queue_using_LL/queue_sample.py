class Node:
    def __init__(self,cargo):
	self.cargo = cargo
	self.next = None

class Queue:
    def __init__(self):
        self.length = 0
        self.head = None

    def is_empty(self):
        return self.length == 0

    def insert(self, cargo):
        node = Node(cargo)
        if self.head is None:
            # If list is empty the new node goes first
            self.head = node
        else:
            # Find the last node in the list
            last = self.head
            while last.next:
                last = last.next
            # Append the new node
            last.next = node
        self.length += 1

    def remove(self):
        cargo = self.head.cargo
        self.head = self.head.next
        self.length -= 1
        return cargo

    def print_queue(self):
	temp = self.head
	while temp:
	    print "%d" % temp.cargo
	    temp = temp.next

q = Queue()

q.insert(1)
q.insert(2)
q.insert(3)
q.insert(4)
q.insert(5)

d1 = q.remove()

print d1

print "Current queue: "

q.print_queue()
