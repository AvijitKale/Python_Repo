class Queue():
	def __init__(self):
		self.items = []

	def enqueue(self,item):
		self.items.insert(0,item)

	def isEmpty(self):
		return len(self.items) == 0

	def size(self):
		return len(self.items)

	def dequeue(self):
		return self.items.pop()

	def printQueue(self):
		for i in range(len(self.items)-1,-1,-1):
			print "Queue element: {0}:: {1}".format(i,self.items[i])

if __name__ == '__main__':
	q = Queue()

	q.enqueue(2)
	q.enqueue(3)
	q.enqueue(4)
	q.enqueue(5)

	q.printQueue()

