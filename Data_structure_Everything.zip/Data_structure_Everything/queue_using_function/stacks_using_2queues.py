class Queue():
	def __init__(self):
		self.items = []

	def enqueue(self,item):
		self.items.insert(0,item)

	def isEmpty(self):
		return len(self.items) == 0

	def size(self):
		return len(self.items)

	def dequeue(self):
		return self.items.pop()

	def printQueue(self):
		for i in range(len(self.items)-1,-1,-1):
			print "Queue element: {0}:: {1}".format(i,self.items[i])


class StacksUsingQueue():
	def __init__(self):
		self.q1 = Queue()
		self.q2 = Queue()

	def push(self,item):
		self.q1.enqueue(item)

	def pop(self):
		while self.q1.size() > 1:
			var = self.q1.dequeue()
			self.q2.enqueue(var)

		value = self.q1.dequeue()
		while self.q2.size() > 0:
			self.q1.enqueue(self.q2.dequeue())
		return value

s = StacksUsingQueue()

s.push(1)
s.push(2)
s.push(3)
s.push(4)
s.push(5)

print ("Popped: ", s.pop())
	

