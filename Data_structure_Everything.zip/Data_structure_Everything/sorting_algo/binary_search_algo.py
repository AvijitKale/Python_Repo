def binary_search(item,itemList):
    found = False
    bottom = 0
    top = len(itemList)-1
    while (bottom <= top and (found== False)):
	middle = (bottom + top ) // 2
	print "-->", middle
	print "+++>", itemList[middle]
	if itemList[middle] == item:
	    found =  True
	elif itemList[middle] < item:
	    bottom = middle +1
	else:
	    top = middle - 1
    return found
	

myList = [1,7,12,26,37,41,56,66,72,80,93]

number = int(input("Enter the number you want to find"))

isitfound = binary_search(number,myList)

if isitfound:
    print "Number found"
else:
    print "Number NOT found"
