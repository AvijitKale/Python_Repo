class Stack(list):

	def __init__(self):
		self.items = []

	def isEmpty(self):
		return self.items == []

	def push(self,items):
		self.items.append(items)

	def pop(self):
		if not self.isEmpty():
			return self.items.pop()
		else:
			raise Exception ("Stack is Empty")

	def peek(self):
		return self.items[-1]

	def size(self):
		return len(self.items) 

	def printStack(self):
		for i in range(len(self.items)):
			print "i:{0}  element:{1}".format(i,self.items[i])
s = Stack()

print "Pushing elements to stack: "
s.push(10)
s.push(13)
s.push(3)
s.push(5)
s.push(7)
s.push(11)

print "Current Stack: "

s.printStack()

ele = s.pop()

print "Popped element :{0} ".format(ele)


top = s.peek()

print "Top of the stack is: {0} ".format(top)

size = s.size()

print "Size of the stack is: {0}".format(size)

flag = s.isEmpty()

print "Stack is empty: {0}".format(flag)	

print "Current Stack: "

s.printStack()
