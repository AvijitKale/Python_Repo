class Node:
	def __init__(self,data):
		self.data =  data
		self.next = None
		
class LinkedList:
	def __init__(self):
		self.head = None
		
	def push(self, new_data):
		new_node = Node(new_data)
		new_node.next = self.head
		self.head = new_node
		
	# Given a reference to the head of a list and a key,
    # delete the first occurence of key in linked list
	def deleteNode(self, key):
		prev = None
		temp = self.head
		
		# If head node itself holds the key to be deleted
		if (temp is not None):
			if(temp.data == key):
				self.head = temp.next
				temp = None
				return
		
		# Search for the key to be deleted, keep track of the
        # previous node as we need to change 'prev.next'
		while(temp is not None):
			if (temp.data == key):
				break
			prev = temp
			temp = temp.next
			
		# if key was not present in linked list
		if (temp == None):
			return
			
		prev.next = temp.next
		
		temp = None
	
	def printList(self):
		temp =  self.head
		while(temp is not None):
			print "%d" %temp.data
			temp =  temp.next
			
	
llist = LinkedList()

llist.push(2)
llist.push(5)
llist.push(6)
llist.push(3)

print "Complete LinkedList:\n"

llist.printList()

print "deleting node 5: \n"

llist.deleteNode(5)

print "Remaining List: \n"

llist.printList()

print "deleting node 3 head node: \n"

llist.deleteNode(3)

print "Remaining List: \n"

llist.printList()

