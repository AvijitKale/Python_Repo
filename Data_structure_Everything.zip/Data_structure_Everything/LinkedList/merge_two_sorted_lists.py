class Node:
	def __init__(self,data):
		self.data = data
		self.next = None


class LinkedList:
	def __init__(self):
		self.head = None


	def push(self,data):
		new_node = Node(data)
		new_node.next = self.head
		self.head = new_node


	def printList(self):
		temp = self.head
		while temp:
			print temp.data
			temp = temp.next


def merge_lists(l1 , l2):
	tmp1 = l1.head
	tmp2 = l2.head
	print tmp1.data, tmp2.data

	if tmp1.data < tmp2.data:
                head = tmp1
                tmp1 = tmp1.next

        if tmp2.data < tmp1.data:
	        head = tmp2
                tmp2 = tmp2.next

	print "tmp1.next", tmp1.data
	start = head
	print start.data
	mergePointer = head

	print "Mp data", mergePointer.data
	mergePointer.next = None

	while tmp1 is not None and tmp2 is not None:
		print "tmp1.data and tmp2.data", tmp1.data , tmp2.data
		if tmp1.data < tmp2.data:
			mergePointer.next = tmp1
			tmp1 = tmp1.next

		else:
			mergePointer.next = tmp2
			tmp2 = tmp2.next
		
		mergePointer = mergePointer.next 


	if tmp1 == None:
		print "tmp2: ", tmp2.data
		mergePointer.next = tmp2
	
	else:
		print "tmp1: ", tmp1.data
		mergePointer.next = tmp1
	
	current = start
	while current:
		print current.data
		current = current.next		
				


list1 = LinkedList()
list2 = LinkedList()


list1.push(8)
list1.push(6)

list1.push(4)
list1.push(2)
list1.push(1)

list2.push(13)
list2.push(11)
list2.push(9)
list2.push(7)

list2.push(5)
list2.push(3)


list1.printList()

list2.printList()
	
		
merge_lists(list1,list2)
	
