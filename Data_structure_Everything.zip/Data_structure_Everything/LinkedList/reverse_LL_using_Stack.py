class Node:
    def __init__(self,data):
        self.data = data
	self.next = None

class Stack:
     def __init__(self):
         self.items = []

     def isEmpty(self):
         return self.items == []

     def push(self, item):
         self.items.append(item)

     def pop(self):
         return self.items.pop()

     def top(self):
         return self.items[len(self.items)-1]

     def size(self):
         return len(self.items)

     def printStack(self):
	 for i in range(len(self.items)):
		print self.items[i] 

class LinkedList:
    def __init__(self):
	self.head = None
	self.s = Stack()

    def push(self,new_data):
	new_node = Node(new_data)
	new_node.next = self.head
	self.head = new_node

    def reverseList(self):
	current = self.head
	prev = None
	while(current):
	    next = current.next
	    current.next = prev
	    prev = current
	    current = next

	self.head = prev

    def reverse_LL(self):
	temp = self.head
	while temp:
	    self.s.push(temp)
	    temp = temp.next
	temp = self.s.top()
	self.head = temp
	while self.s.size() > 1:
	    temp = self.s.pop()
	    print "1: %d", temp.data
	    temp.next = self.s.top()
	    temp = temp.next
	    print "2: %d", temp.data
	temp.next = None


    def lengthList(self):
	current = self.head
	count = 0
	while(current):
	    current = current.next
	    count = count +1
	return count	

    def printList(self):
	temp = self.head
	while(temp):
	    print "%d" %temp.data
	    temp = temp.next


llist = LinkedList()
llist.push(1)
llist.push(2)
llist.push(3)
llist.push(4)
llist.push(5)
llist.push(6)
llist.push(7)
llist.push(8)
llist.push(9)
llist.push(10)
llist.push(11)
llist.push(12)

count = llist.lengthList()
print "length of list is:%d" % count

print "Original List:\n"
llist.printList()

print "Reverse Linked List using iteration: \n"

llist.reverseList()

llist.printList()

print "Reverse Linked List using Stack: "

llist.reverse_LL()

print "After reversing List:\n"

llist.printList()

