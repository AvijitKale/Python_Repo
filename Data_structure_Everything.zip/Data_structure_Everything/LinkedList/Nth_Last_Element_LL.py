class Node:
	def __init__(self,data):
		self.data = data
		self.next = None


class LinkedList:

	def __init__(self):
		self.head = None


	def push(self, new_data):
		new_node = Node(new_data)
		new_node.next = self.head
		self.head = new_node


	def print_NthLast_element(self,n):	
		main_ptr = self.head
		ref_ptr = self.head

		count = 0
		while count < n:
			if ref_ptr is None:
				print "Nth Last element is not possible"
			ref_ptr = ref_ptr.next
			count += 1
			print "ref_ptr : ", ref_ptr.data


		while (ref_ptr is not None):
			main_ptr = main_ptr.next
			ref_ptr = ref_ptr.next


		print "{0}th element from Last in the linkedlist is : {1}".format(n,main_ptr.data)

	def print_LL(self):
	
		current = self.head
		while current:
			print "Element: ", current.data
			current = current.next


ll = LinkedList()

ll.push(1)
ll.push(2)
ll.push(3)
ll.push(4)
ll.push(5)
ll.push(6)
ll.push(7)
ll.push(8)

print "Linked List: "
ll.print_LL()

print "\n\n"
ll.print_NthLast_element(5)

print "\n\n"

ll.print_NthLast_element(6)		

