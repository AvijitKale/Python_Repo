"""
printLevelorder(tree)
1) Create an empty queue q
2) append root to queue
3) Loop while queue is not EMPTY
    a) pop node from queue which is temp_node
    a) print temp_node->data.
    b) Enqueue temp_node’s children (first left then right children) to q

"""

class Node:
	def __init__(self, data):
		self.data =  data
		self.left = None
		self.right = None

def LevelTraversal(root):

	queue = []

	result = []

	if root is None:
		return

	queue.append(root)

	while len(queue) > 0:

		node = queue.pop(0)

		result.append(node.data)

		if node.left is not None:
			queue.append(node.left)
		if node.right is not None:
			queue.append(node.right)

	return result


root = Node(1)

root.left = Node(2)

root.right = Node(3)

root.left.left = Node(4)

root.left.right = Node(5)

result = []

result = LevelTraversal(root)

print result
