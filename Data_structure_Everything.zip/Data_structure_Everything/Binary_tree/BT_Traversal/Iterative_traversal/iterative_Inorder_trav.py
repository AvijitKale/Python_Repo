

# A binary tree node
class Node:

    # Constructor to create a new node
    def __init__(self, data):
        self.data = data
        self.left = None
        self.right = None

def inorderTraversal(root):
        # Handle with the special cast (empty input)
        if root == None:        return []
 
        stack = [root]
        current = root.left
        result = []
 
        while len(stack) != 0 or current != None:
            # Find the leftmost node among all the un-accessed ones.
            while current != None:
                stack.append(current)
                current = current.left
 
            # Fetch the value in currently leftmost node
            current = stack.pop()
            result.append(current.data)
 
            # Try the right son of current node
            current = current.right
 
        return result



# Driver program to test above function
root = Node(1)
root.left      = Node(2)
root.right     = Node(3)
root.left.left  = Node(4)
root.left.right  = Node(5)
root.right.left = Node(6)
root.right.right = Node(7)
root.left.left.left = Node(8)
root.left.left.right = Node(9)


result = []
result = inorderTraversal(root)

print result

