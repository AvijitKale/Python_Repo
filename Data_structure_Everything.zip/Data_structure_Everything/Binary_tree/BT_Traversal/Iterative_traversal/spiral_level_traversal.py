"""
Algorithm: 
1. Push root node into the 'stackEven'. Set boolean 'evenLevel' to true. This boolean variable is used to indicate if the current level being visited is even level or odd level.

2. Now if 'evenLevel' is set to true repeat steps 2a to 2c until 'stackEven' is not empty.
  2a. Pop the node from 'stackEven'. Let popped node be 'currentNode'. Print the value of 'currentNode'.
  2b. If the right child of 'currentNode' is not null, push it into the 'stackOdd'.
  2c. If the left child of 'currentNode' is not null, push it into the 'stackOdd'.
Notice that currentNode's right child is pushed first and then its left child is pushed.
  
3. If 'evenLevel' is not set to true then repeat steps 3a to 3c until 'stackOdd' is not empty.
  3a. Pop the node from 'stackOdd'. Let popped node be 'currentNode'. Print the value of 'currentNode'.
  3b. If the left child of 'currentNode' is not null, push it into the 'stackEven'.
  3c. If the right child of 'currentNode' is not null, push it into the 'stackEven'.
Notice that currentNode's left child is pushed first and then its right child is pushed.
  
4. If 'evenLevel' is true set it to false and if it is false set it to true. This is because the next level visited would be odd if current level is even and vice versa.

5. Repeat steps 2-4 until both 'stackEven' and 'stackOdd' are not empty. 
"""


from pythonds.basic.stack import Stack


class Node:
	def __init__(self,data):
		self.data = data
		self.left = None
		self.right = None

def spiral_level_traversal(root):
	
	stackEven = Stack()
	stackOdd = Stack()
	stackEvenFlag = True

	if root:
		stackEven.push(root)


	while stackEven.size() > 0 or stackOdd.size() > 0:
		while stackEven.size() > 0 and stackEvenFlag:
			node = stackEven.pop()

			print node.data

			if node.right:
				stackOdd.push(node.right)
			if node.left:
				stackOdd.push(node.left)
		
			if stackEven.size() == 0:
				stackEvenFlag = False

		while stackOdd.size() > 0 and stackEvenFlag == False:
			node = stackOdd.pop()
			
			print node.data

			if node.left:
				stackEven.push(node.left)
			if node.right:
				stackEven.push(node.right)

			if stackOdd.size() == 0:
				stackEvenFlag = True
			

root = Node(1)

root.left = Node(2)

root.right = Node(3)

root.left.left = Node(4)

root.left.right = Node(5)

root.right.left = Node(6)

root.right.right = Node(7)

root.left.left.left = Node(8)

root.left.left.right = Node(9)

root.left.right.left = Node(10)

root.left.right.right = Node(11)

root.right.left.left = Node(12)

root.right.left.right = Node(13)

root.right.right.left = Node(14)

root.right.right.right = Node(15)

root.left.left.left.left = Node(16)

root.left.left.left.right = Node(17)

root.left.left.right.left = Node(18)

root.left.left.right.right = Node(19)

root.left.right.left.left = Node(20)

root.left.right.left.right = Node(21)

root.left.right.right.left = Node(22)

root.left.right.right.right = Node(23)

root.right.left.left.left = Node(24)

root.right.left.left.right = Node(25)

root.right.left.right.left = Node(26)

root.right.left.right.right = Node(27)

root.right.right.left.left = Node(28)

root.right.right.left.right = Node(29)

root.right.right.right.left = Node(30)

root.right.right.right.right = Node(31)

root.left.left.left.left.left = Node(32)

root.left.left.left.left.right = Node(33)




spiral_level_traversal(root)




