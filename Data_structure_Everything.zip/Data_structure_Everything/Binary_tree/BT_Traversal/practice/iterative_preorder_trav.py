"""
1) Create an empty stack nodeStack and push root node to stack.
2) Do following while nodeStack is not empty.
	a) Pop an item from stack and print it.
	b) Push right child of popped item to stack
	c) Push left child of popped item to stack

Since we have to print left node before than right node.... we have to push right node before left node

"""


class Node:
	def __init__(self,data):
		self.data = data
		self.left = None
		self.right = None


def iterativePreorder(root):

	if root is None:
		return

	nodeStack = []
	nodeStack.append(root)

	while len(nodeStack) > 0:
		node = nodeStack.pop()

		print node.data

		if node.right is not None:
			nodeStack.append(node.right)

		if node.left is not None:
			nodeStack.append(node.left)


root = Node(1)

root.left = Node(2)

root.right = Node(3)

root.left.left = Node(4)

root.left.right = Node(5)

root.right.left = Node(6)

root.right.right = Node(7)


iterativePreorder(root)
