class Node:
    def __init__(self,data):
	self.data = data
	self.next = None

class Stack:
    def __init__(self):
	self.top = None

    def push(self,new_data):
	new_node = Node(new_data)
	new_node.next = self.top
	self.top = new_node

    def pop(self):
	value = self.top.data
	self.top = self.top.next
	return value
    
    def printStack(self):
	temp = self.top
	while(temp):
	    print "%d" % temp.data
	    temp = temp.next

    def isEmpty(self):
	if(self.top == None):
	    return True
	else:
	    return False


s= Stack()
s.push(1)
s.push(2)
s.push(3)
s.push(4)
s.push(5)
s.push(6)
s.push(7)

print "Original Stack :"
s.printStack()

print "popping one element"

print s.pop()

print "Stack after popping one element:"

s.printStack()	

print "Checking if stack is Empty:"

print s.isEmpty()


print s.pop()

print "popping one element:"

print "Stack after popping one element:"

s.printStack()

print "Checking if stack is Empty:"

print s.isEmpty()
